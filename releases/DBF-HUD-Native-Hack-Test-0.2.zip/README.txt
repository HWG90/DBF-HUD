Disable previous native-font depth/loader test packages. Enable this package alone, deploy in Arsenal and restart.
The main HUD is unchanged. Use the separate MDL font probe to validate registration, appearance and occlusion.
First test covers the 193 template characters; full Nerd icon coverage is not included.
