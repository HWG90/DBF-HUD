Replace prior Hack/native-font test assets with this library. Deploy in Arsenal and restart. Enable only this native-font asset package.
72 families, one regular face each; template Latin/ASCII coverage, not full Nerd Unicode. Only Hack is live-verified. Symbols-only ASCII uses Hack fallback.
